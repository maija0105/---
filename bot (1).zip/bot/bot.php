<?php


require_once 'telelibonphp-master/tgLib.php'; //Подключаем библиотеку TG
require_once "simplevk-master/autoload.php"; //Подключаем библиотеку VK

use DigitalStar\vk_api\vk_api;

$data = json_decode(file_get_contents('php://input'),true);
$group_id = $data['group_id']  ?? null;

$platform = '';

if ($group_id !== null) {
    $vk = vk_api::create('АПИ ключ ВК', '5.131')->setConfirm('320105f2');
    $vk->initVars($peer_id, $message, $payload, $user_id, $type, $data); // Инициализация переменных
    $payload = $payload['command'];
    $platform = 'vk';
} else {
    $vk = new tgBot('токен ТГ');
    $message = $data['callback_query']['message']['text'] ?? $data['message']['text'] ?? null;
    $peer_id = $data['callback_query']['message']['chat']['id'] ?? $data['message']['chat']['id'] ?? null;
    $user_id = $data['callback_query']['message']['from']['id'] ?? $data['message']['from']['id'] ?? null;
    $payload = $data['callback_query']['data'];
    $platform = 'tg';
}

$command = explode(' ', mb_strtolower($message));

// Обработка команд
if ($command[0] == 'время') {

    $date = date('d.m.y H:i:s');
    $vk->sendMessage($peer_id, "Серверное время: $date");
    exit;
}

if ($command[0] == 'инфо') {

    $vk->sendMessage($peer_id, "Я бот и я умею работать в ВК и Телеграмм");
    exit;
}

if ($command[0] == 'кнопка') {


    if ($platform == 'vk'){ // Если событие из вк
        // Кнопка ВК
        $started = $vk->buttonText('Нажми меня', 'green', ['command' => 'play']);
        $kbd = [[$started]];
    } else { // Иначе вставляем кнопку для телеги
        // Кнопка TG
        $kbd = [
            'inline_keyboard' => [
                [['text' => 'Нажми меня', 'callback_data' => 'play']]
            ]
        ];
    }


    $vk->sendButton($peer_id, "Держи кнопку, но знай, она отличается от выбраного месенджера", $kbd);
    exit;
}


if ($payload == 'play'){

    $vk->sendMessage($peer_id, "Ты нажал кнопку и я выполяю на это какое-то событие...");
    exit;
}

// Класичиский ответ
$vk->sendMessage($peer_id, "Приветик :)");
