
<div class="tab-pane p-3 active" id="home" role="tabpanel">

    <form method="POST" id="formx" action="javascript:void(null);" onsubmit="call()">
        <input type="hidden" name="type" value="mailing">
        <input type="hidden" name="group_id" value="<? print $group_id ?>">
    <p class="mb-0 text-muted">





    <div class="form-group">
        <label for="message">Сообщение для рассылки
            <p class="text-muted mb-4 font-13">Не злоупотребляйте рассылками, это может повлечь отток пользователей. Максимальная длина текста 4000 символов. Частота рассылок - 5 в сутки!</p>

        </label>
        <textarea id="mailing" name="mailing" class="form-control" rows="5" style="margin-top: 0px; margin-bottom: 0px; height: 105px;"></textarea>
    </div>


    </p>

        <style>
            #save, #dont_save{display:none}
        </style>



        </p>





        <div class="form-group">
            <button value="Send" type="submit" class="btn btn-success waves-effect waves-light"><i class="mdi mdi-check-all mr-2"></i>Начать рассылку</button>
        </div>

        <div id="save" class="alert icon-custom-alert alert-outline-success alert-success-shadow" role="alert">
            <div class="alert-text">
                <i class="mdi mdi-check-all alert-icon"></i>
                <strong>Рассылка началась!</strong>
            </div>
        </div>

        <div id="dont_save" class="alert icon-custom-alert alert-outline-danger alert-success-shadow" role="alert">
            <div class="alert-text">

                <div id="results"></div>
            </div>
        </div>




</div>

</form>






<div id="custom-modal" class="modal-demo">
    <button type="button" class="close" onclick="Custombox.modal.close();">
        <span>&times;</span><span class="sr-only">Close</span>
    </button>
    <h4 class="custom-modal-title">Список всех тегов и их описание</h4>
    <div class="custom-modal-text">
        Вcе доступные теги обозначаються рядом с дочерним полем и могут применяться только там, теги прописанные вручную из другой коллекции работать не будут!<br>
        <br>
        Список тегов и их описание:<br>
        {@bot} - Данный тег приобразуется в упоминание сообщетсва от которого пришло сообщение пользователю<br>
        {bot} - Данный тег содержит только названия сообщества, с которого пришло сообщение пользователю<br>

    </div>
</div> <!--end custom modal-->

<div id="custom-modal1" class="modal-demo">
    <button type="button" class="close" onclick="Custombox.modal.close();">
        <span>&times;</span><span class="sr-only">Close</span>
    </button>
    <h4 class="custom-modal-title">Список администраторов</h4>
    <div class="custom-modal-text">
        Укажите через запятую ID пользователей ВК, которые смогут управлять настройками группы через панель управления на сайте. Будьте внимательны, пользователю выдаются полные права на управление группой на сайте VLITO.ru
        <br>
        <br>
        Пользователю не будет доступна панель управления без прав администора в самой группе. Имейте это ввиду!

    </div>
</div> <!--end custom modal-->


<script>


    function call() {
        var msg   = $('#formx').serialize();
        document.getElementById("save").style.display = "block";
        $.ajax({
            type: 'POST',
            url: '/bots/shpion/func.php',
            data: msg,
            success: function(data) {
                console.log(data);
                var obj = jQuery.parseJSON(data);
                if (obj.success == "success") {
                    $('#results1').html(obj.error);
                    document.getElementById("save").style.display = "block";
                    document.getElementById("dont_save").style.display = "none";
                }else{
                    $('#results').html(obj.error);
                    document.getElementById("dont_save").style.display = "block";
                    document.getElementById("save").style.display = "none";
                }
            }
        });

    }




</script>