<?
if( !defined('ACCESS') ) {
    header("HTTP/1.1 403 Forbidden");
    header('Location: ../../');
    die("Hacking attempt!");
}
$group_id = $_GET['group'];


$u_balance	= 0.00;
$u_balance_day	= 0.00;
$u_balance_week = 0.00;
$u_balance_month = 0.00;

$result	= $db->query("SELECT * FROM enter WHERE status = 2 and group_id = ?i", $group_id);


while($row = $result->fetch_assoc()) {

    $u_balance = $u_balance + $row['sum']; // За все время

    $you_date_day = date('d.m.Y', $row['date']); // Дата с бд
    $now_date_day = date('d.m.Y'); // Текущая дата
    $you_date_unix_day = strtotime($you_date_day);
    $now_date_unix_day = strtotime($now_date_day);

    $you_date_week = date('W.m.Y', $row['date']); // Дата с бд
    $now_date_week = date('W.m.Y'); // Текущая дата
    $you_date_unix_week = strtotime($you_date_week);
    $now_date_unix_week = strtotime($now_date_week);

    $you_date_month = date('M.Y', $row['date']); // Дата с бд
    $now_date_month = date('M.Y'); // Текущая дата
    $you_date_unix_month = strtotime($you_date_month);
    $now_date_unix_month = strtotime($now_date_month);

    if ($you_date_unix_day == $now_date_unix_day){ // За текущий день
        $u_balance_day = $u_balance_day + $row['sum'];
    }
    if ($you_date_unix_week == $now_date_unix_week){ // Зе текущую неделю
        $u_balance_week = $u_balance_week + $row['sum'];
    }
    if ($you_date_unix_month == $now_date_unix_month){ // За текущий месяц
        $u_balance_month = $u_balance_month + $row['sum'];
    }

}



$u_benefit	= 0.00;
$result	= $db->query("SELECT * FROM rshop.users WHERE group_id = ?i", $group_id);
while($row = $result->fetch_assoc()) {
    $u_benefit = $u_benefit + $row['benefit'];
}



print '<div class="tab-pane p-3 active" id="profile" role="tabpanel">








<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h4 class="mt-0 header-title">Сортировка</h4>
                
                <div class="general-label">
                    <form class="form-inline" role="form" action="/bots/" method="GET">
                       
                    
                                        <input type="hidden" name="group" value="'.$group_id.'">    
                                        <input type="hidden" name="p" value="pay">
                                        <input type="hidden" name="page" value="'.intval($_GET['page']).'">

                  
                                        <div class="input-group">
                                        
                                        
                                                       <select name="sort" class="custom-select"">
                                            <option value="id">Сортировать по ID</option>
                                            <option value="balance">Сортировать по балансу</option>
                                        </select>
                                        
                                                 <select name="DA" class="custom-select">
                                            <option value="desc"> На убывание</option>
                                            <option value="asc">На увеличение</option>
                                        </select>
                                                <div class="input-group-append">
                                                    <button class="btn btn-outline-primary" type="submit">Применить</button>
                                                </div>
                                            </div>
                                            
                         
                                  
             
                   
            
                    </form>
                    
                    
                    
                    
                </div>
            </div><!--end card-body-->
        </div><!--end card-->
        
        
        
        
        
        
                <div class="card">
            <div class="card-body">
                <h4 class="mt-0 header-title">Поиск</h4>
                
                <div class="general-label">
                    <form class="form-inline" role="form" action="/bots/" method="GET">
                         <input type="hidden" name="group" value="'.$group_id.'">    
                                        <input type="hidden" name="p" value="pay">
                    
                                      <div class="form-group mb-0">
                                       
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text">ID / Баланс</span>
                                                </div>
                                                <input type="text" name="search" class="form-control">                                                <div class="input-group-append">
                                                    <button class="btn btn-outline-primary" type="submit">Применить</button>
                                                </div>
                                              
                                            </div>
                                        </div>
             
                   
            
                    </form>
                    
                    
                    
                    
                </div>
            </div><!--end card-body-->
        </div><!--end card-->
        
        
        
    </div><!--end col-->
</div>



    <p class="mb-0 text-muted">




        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">

                    <h4 class="mt-0 header-title">Список всех платежей</h4>
                    
                    <div class="row justify-content-center">
                                                <div class="col-md-3">
                                                    <div class="card mb-0">
                                                        <div class="card-body">
                                                            <div class="float-right">
                                                                <i class="dripicons-wallet font-20 text-secondary"></i>
                                                            </div> 
                                                            <span class="badge badge-danger">За день</span>
                                                            <h3 class="font-weight-bold">'.number_format($u_balance_day, 0, ' , ', ' ').' <i class="fas fa-ruble-sign"></i></h3>
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="card mb-0">
                                                        <div class="card-body">
                                                            <div class="float-right">
                                                                <i class="dripicons-wallet font-20 text-secondary"></i>
                                                            </div> 
                                                            <span class="badge badge-info">Неделя</span>
                                                            <h3 class="font-weight-bold">'.number_format($u_balance_week, 0, ' , ', ' ').' <i class="fas fa-ruble-sign"></i></h3>
                                                           
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="card mb-0">
                                                        <div class="card-body">
                                                            <div class="float-right">
                                                                <i class="dripicons-wallet font-20 text-secondary"></i>
                                                            </div> 
                                                            <span class="badge badge-warning">Месяц</span>
                                                            <h3 class="font-weight-bold">'.number_format($u_balance_month, 0, ' , ', ' ').' <i class="fas fa-ruble-sign"></i></h3>
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="card mb-0">
                                                        <div class="card-body">
                                                            <div class="float-right">
                                                                <i class="dripicons-wallet font-20 text-secondary"></i>
                                                            </div> 
                                                            <span class="badge badge-success">За все время</span>
                                                            <h3 class="font-weight-bold">'.number_format($u_balance, 0, ' , ', ' ').' <i class="fas fa-ruble-sign"></i></h3>
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                    
                    
    <p class="text-muted mb-4"></p>

    <div class="table-responsive">
        <table id="withdraws-tbl" class="table table-bordered mb-0 table-centered">
            <thead>
            <tr>
              
                <th>ID</th>
                <th class="tbl-name">VK</th>
                <th>Сумма</th>
                <th>Дата</th>
            </tr>
            </thead>
            <tbody>';


$num = 20;
$page	= intval($_GET['page']);
$query	= "SELECT * FROM enter WHERE group_id = ?i and (status = 2 or status = 3) and pay_id > 0" ;
$result	= $db->query($query, $group_id);
$themes = $result->getNumRows();
$total	= intval(($themes - 1) / $num) + 1;

if(empty($page) or $page < 0) $page = 1;
if($page > $total) $page = $total;
$start = $page * $num - $num;


switch ($_GET['sort'])
{


    case 'balance':
        $sql_sort = 'ORDER BY sum';
        break;
    default:
        $sql_sort = 'ORDER BY id';
        break;
}

$sql_da = 'DESC';
if ($_GET['DA'] == 'asc') {$sql_da = 'ASC';} else {$sql_da = 'DESC';}

if (isset($_GET['search'])){

    $search =   htmlspecialchars($_GET['search']);


    $result = $db->query($query." and (id LIKE '$search' or pay_id LIKE '$search' or sum LIKE '$search')  LIMIT 30", $group_id);
    $result1 = $db->query($query." and (id LIKE '$search' or pay_id LIKE '$search' or sum LIKE '$search') LIMIT 30", $group_id);

} else {

    $result = $db->query($query." $sql_sort $sql_da LIMIT ".$start.", ".$num, $group_id);
    $result1 = $db->query($query." $sql_sort $sql_da LIMIT ".$start.", ".$num, $group_id);

}



if(!$themes) {
    // print "<div class=\"alert alert-info\">У Вас еще нет добавленных ботов</div>";
} else {

    //$count_users = $db->query("SELECT * FROM rshop.users WHERE group_id = ?i order by id DESC",$group_id);



    // $result_users = $db->query("SELECT * FROM rshop.users WHERE group_id = ?i order by id DESC LIMIT 50", $group_id);
    $esum = 0;
    $i = 0;
    $count_balance = 0;
    while ($row_user = $result->fetch_assoc()) {


        $info_vk = unserialize($row_user['info_vk']);
        $date_time = date('d.m.y H:i:s',$row_user['date']);

        print "<tr role='row' id='$row_user[id]' class='odd'>
        
               <td>$row_user[id]</td>
                <td><a href=\"https://vk.com/id$row_user[pay_id]\" target='_blank'> <img src=\"$info_vk[avatar]\" alt=\"\" class=\"rounded-circle thumb-sm mr-1\">
                                                    $info_vk[first_name] $info_vk[last_name]</a></td>
 <td>$row_user[sum]</td>
 <td>$date_time</td>

    </tr>";
        $i++;
        $count_balance = $count_balance + $row_user['sum'];
    }
}
print' <tr>

        <td></td>
        <td>Всего</td>
        <td>'.$count_balance.' р.</td>
         <td></td>
 

    </tr> </tbody></table></div><!--end /tableresponsive-->

</div><!--end card-body-->
</div><!--end card-->
</div> <!-- end col -->

</p>
</div>   ';


if ($page) {
    if($page != 1) { $pervpage = "<li class=\"page-item\"><a class=\"page-link\" href=\"/bots/?group=$group_id&p=pay&sort={$_GET['sort']}&DA={$_GET['DA']}&page=". ($page - 1) ."\">««</a></li>"; } // Если страница не 1 то рисуем стрелку влево
    if($page != $total) { $nextpage = "<li class=\"page-item\"><a class=\"page-link\" href=\"/bots/?group=$group_id&p=pay&sort={$_GET['sort']}&DA={$_GET['DA']}&page=". ($page + 1) ."\">»»</a></li>"; } // Если страница не последняя то ресуем стрелку вправо
    if($page - 2 > 0) { $page2left = " <li class=\"page-item\"><a class=\"page-link\" href=\"/bots/?group=$group_id&p=pay&sort={$_GET['sort']}&DA={$_GET['DA']}&page=". ($page - 2) ."\">". ($page - 2) ."</a> </li>"; } // Показываем кнопку если слева нет смещения на 2
    if($page - 1 > 0) { $page1left = " <li class=\"page-item\"><a class=\"page-link\" href=\"/bots/?group=$group_id&p=pay&sort={$_GET['sort']}&DA={$_GET['DA']}&page=". ($page - 1) ."\">". ($page - 1) ."</a> </li>"; }
    if($page + 2 <= $total) { $page2right = " <li class=\"page-item\"><a class=\"page-link\" href=\"/bots/?group=$group_id&p=pay&sort={$_GET['sort']}&DA={$_GET['DA']}&page=". ($page + 2) ."\">". ($page + 2) ."</a> </li>"; }
    if($page + 1 <= $total) { $page1right = " <li class=\"page-item\"><a class=\"page-link\" href=\"/bots/?group=$group_id&p=pay&sort={$_GET['sort']}&DA={$_GET['DA']}&page=". ($page + 1) ."\">". ($page + 1) ."</a> </li>"; }
    if($page + 3 <= $total) { $page1finish = " <li class=\"page-item\"><a class=\"page-link\" href=\"/bots/?group=$group_id&p=pay&sort={$_GET['sort']}&DA={$_GET['DA']}&page=". ($total) ."\">...". ($total) ."</a> </li>"; }
    if($page - 3 > 0) { $page1start = " <li class=\"page-item\"><a class=\"page-link\" href=\"/bots/?group=$group_id&p=pay&sort={$_GET['sort']}&DA={$_GET['DA']}&page=". (1) ."\">". (1) ."...</a></li> "; }
}

if ($pervpage or $nextpage) { print "<nav aria-label=\"Page navigation example\"> <ul class=\"pagination justify-content-center\">".$pervpage.$page1start.$page2left.$page1left." <li class=\"page-item active\"><a class=\"page-link\">$page</a></li>".$page1right.$page2right.$page1finish.$nextpage."</ul><!--end pagination-->
                                    </nav>"; }





print '';
