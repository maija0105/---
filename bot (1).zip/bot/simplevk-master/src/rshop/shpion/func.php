<?php
//session_start();
include '../../cfg.php';
include '../../ini.php';
use DigitalStar\vk_api\VK_api as vk_api; // Основной класс





$sid = $_COOKIE['vlitohash'];
$type = $_POST['type'];
$group_id = $_POST['group_id'];

$user_id = $db->query("SELECT ids FROM users WHERE setcookie = '?s'", $sid)->fetch_assoc()['ids'];


$name_group = $vk->request('groups.getById', ['group_ids' => $group_id, 'fields' => 'admin_level']); //


if ($name_group[0]['is_admin'] == 1 and $name_group[0]['admin_level'] == 3 and $user_id != '' or $adm == 1) {


//print $sid;

    /*if (!$admin){
        exit();
    }*/


    $select_bots = $db->query("SELECT * FROM bots WHERE bot_id = ?i", $group_id)->fetch_assoc();
    $owner_id = $select_bots['owner_id'];
    $admins = $select_bots['admin_ids'];
    $spam_time = $select_bots['spam_time'];
    $spam_time_u = date('d.m.y H:i:s', $spam_time);
    $token = $select_bots['token'];
//print_r($_POST);
//
//    [chat_1] =>
//    [chat_2] =>
//    [chat_3] =>
//    [chat_4] =>
//    [chat_5] =>
//    [chat_6] =>
//


    if ($type == "main_settings") {


        $admin_id = $_POST['admin_id'];
        $start_msg = $_POST['start_msg'];
        $info_msg = $_POST['info_msg'];
        $info_msg_2 = $_POST['info_msg_2'];
        $help_msg = $_POST['help_msg'];
        $total = $_POST['total'];
        $un_total = $_POST['un_total'];
        $percent = $_POST['percent'];
        $mess = '';

        if (!$start_msg) {
            $mess .= 'Не указано стартовое сообщение!<br>';
        }
        if (!$info_msg) {
            $mess .= 'Не указано последнее сообщение при завершении регистрации<br>';
        }
        if (!$help_msg) {
            $mess .= 'Не указан текст подсказки<br>';
        }
        if (!$total) {
            $mess .= 'Не верно указана сумма проверки!<br>';
        }
        if (!$un_total) {
            $mess .= 'Не верно указана сумма безлимитной проверки!<br>';
        }
        if (!$percent || $percent < 0 || $percent > 99) {
            $mess .= 'Не верно указан процент!<br>';
        }

        if ($mess != '') {
            $result = array(
                'success' => "error",
                'error' => "$mess"

            );
            echo json_encode($result);
            exit();
        } else {


            $result = array(
                'success' => "success",
                'error' => "$mess"
            );


            $start_msg = [1 => $start_msg, 2 => $info_msg, 3 => $help_msg, 4 => $info_msg_2];
            $db->query("UPDATE testbots3.settings SET msg = '?s', total = ?d, un_total = ?d, procent = ?i WHERE group_id = ?i", serialize($start_msg), $total, $un_total, $percent, $group_id);
            $db->query("UPDATE bots SET admin_ids = '?s' WHERE bot_id = ?i", $admin_id, $group_id);
        }


    }

    if ($type == 'mailing') {

        $mailing = $_POST['mailing'];

        if (!$mailing) {
            $mess .= 'Не указано сообщение для рассылки!<br>';
        }
        if ((strlen($mailing) > 4000 || strlen($mailing) < 10)) {
            $mess .= 'Сообщение для рассылки должно быть от 10 до 4000 символов!<br>';
        }
        if ($spam_time > time()) {
            $mess .= 'Следующая рассылка доступна ' . $spam_time_u . ' (МСК)<br>';
        }

        if ($mess != '') {
            $result = array(
                'success' => "error",
                'error' => "$mess"

            );
            echo json_encode($result);
            exit();
        } else {


            $res = $db->query("SELECT * FROM testbots3.users where group_id = ?i", $group_id);// Последовательно получать в виде ассоциативных массивов


            $ids = [];
            while ($rowss = $res->fetch_assoc()) {

                $ids[] = $rowss['uid'];

            }

            $db->query("UPDATE bots SET spam_time = ?i WHERE bot_id = ?i", time() + 1000, $group_id);


            $result = array(
                'success' => "success",
                'error' => "$mess"
            );
            // echo json_encode($result);


            $i = 0;
            $ids = array_chunk($ids, 100);
            $vk = vk_api::create($token, VERSION);
            foreach ($ids as $ids_chunk) {
                $i++;
                try {
                    $vk->request('messages.send', ['user_ids' => join(',', $ids_chunk), 'message' => $mailing]);

                } catch (Exception $e) {
                    continue;
                }
            }

            // $mess .= 'Было отправлено "'.$i.'" сообщений!';


            //$vk->sendMessage(183657, $sub_ids);


        }

    }


} else {

    $_SESSION['user'] = "";

    setcookie("id_system", '', time() - 1, "/");
    setcookie("vlitohash", '', time() - 1, "/");
    $login = "";
   // print "<html><head><script language=\"javascript\">top.location.href=\"/\";</script></head></html>";
    exit();

}

echo json_encode($result);