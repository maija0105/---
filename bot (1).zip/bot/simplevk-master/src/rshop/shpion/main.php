<?php


// === Выгрузка настроек с VLITO ===

$settings = $db->query("SELECT * FROM testbots3.settings WHERE group_id = ?i LIMIT 1", $name_group[0]['id'])->fetch_assoc();
$params_msg = [1 => 'Бот собирает информацию о профиле Вконтакте 🤖
Команды для управления:

* Получить информацию
* Баланс
* Пополнить',
    2 => 'Информация пользователя:

ID пользователя: {vk_id}
Имя: {first_name}
Фамилия: {last_name}
📅 Дата рождения: {date_br}

💌 Кого лайкает пользователь: ?
🏆 Важные друзья пользователя: ?
👥 Скрытые друзья пользователя: ?

💰 Цена всех функций: {price}

Пополнить 👉🏻 {pay_url}',
    3 => 'Пришлите ссылку пользователя VK что бы получить данные о нем:',
    4 => '{first_name} {last_name} {s} {rand} {gender} из друзей 😳'];

if (!isset($settings))
{


    $db->query("INSERT INTO testbots3.settings (msg, group_id) VALUES ('?s',  ?i)", serialize($params_msg),  $name_group[0]['id']);
    $settings = $db->query("SELECT * FROM testbots3.settings WHERE group_id = ?i LIMIT 1", $name_group[0]['id'])->fetch_assoc();

}


$one_price = $settings;
$total = $settings['total'];
$un_total = $settings['un_total'];
$procent = $settings['procent'];
$reg_msg = unserialize($settings['msg']);
if ($reg_msg[1] == '') {$reg_msg_one = $params_msg[1];} else {$reg_msg_one = $reg_msg[1];}
if ($reg_msg[2] == '') {$reg_msg_two = $params_msg[2];} else {$reg_msg_two = $reg_msg[2];}
if ($reg_msg[3] == '') {$reg_msg_three = $params_msg[3];} else {$reg_msg_three = $reg_msg[3];}
if ($reg_msg[4] == '') {$reg_msg_four = $params_msg[4];} else {$reg_msg_four = $reg_msg[4];}

?>



<div class="tab-pane p-3 active" id="home" role="tabpanel">

    <form method="POST" id="formx" action="javascript:void(null);" onsubmit="call()">

    <p class="mb-0 text-muted">

        <input type="hidden" name="type" value="main_settings">
        <input type="hidden" name="group_id" value="<? print $group_id ?>">
    <div class="form-group">
        <label for="example-input1-group1">Администраторы через запятую <a href="#custom-modal1" class="btn btn-soft-success btn-round waves-effect waves-light" data-animation="blur" data-plugin="custommodal" data-overlaycolor="#38414a"> ? </a></label>
        <div class="input-group">
            <div class="input-group-prepend">
                <span class="input-group-text"><i class="fas fa-user"></i></span>
            </div>
            <input type="text" id="example-input1-group1" name="admin_id"  class="form-control" value="<? print $select['admin_ids']; ?>" placeholder="Укажите ID's администраторов (не обязательно)">
        </div>
    </div>


    <div class="form-group">
        <label for="example-input1-group1">Стоимость 1 проверки</label>
        <div class="input-group">
            <div class="input-group-prepend">
                <span class="input-group-text"><i class="fas fa-ruble-sign"></i></span>
            </div>
            <input type="text" id="example-input1-group1" name="total" class="form-control" placeholder="Укажите сумму (Обязательно)" value="<? print $total; ?>">
        </div>
    </div>

    <div class="form-group">
        <label for="example-input1-group1">Стоимость безлимита</label>
        <div class="input-group">
            <div class="input-group-prepend">
                <span class="input-group-text"><i class="fas fa-ruble-sign"></i></span>
            </div>
            <input type="text" id="example-input1-group1" name="un_total" class="form-control" placeholder="Укажите сумму (Обязательно)" value="<? print $un_total; ?>">
        </div>
    </div>

        <div class="form-group">
            <label for="example-input1-group1">Внутренний процент

                <p class="text-muted mb-4 font-13">Данный процент списывается с суммы пополнения пользователя, рекомендуется устанавливать значение в диапозоне 3-5%</p>
            </label>
            <div class="input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text"><i class="fas fa-percent"></i></span>
                </div>
                <input type="text" id="example-input1-group1" name="percent" class="form-control" placeholder="Укажите процент от 0 до 99 (Обязательно)" value="<? print $procent; ?>">
            </div>
        </div>

    <div class="form-group">
        <label for="message">Стартовое сообщение

            <p class="text-muted mb-4 font-13">Доступные теги: <code class="highlighter-rouge">{bot}, {@bot}, {first_name}, {last_name}, {vk_id}</code></p>
        </label>
        <textarea placeholder="Укажите текст (Обязательно)" class="form-control" name="start_msg" rows="5" style="margin-top: 0px; margin-bottom: 0px; height: 105px;"><? print $reg_msg_one ?></textarea>
    </div>



    </p>




    <div class="form-group">
        <label for="message">Информация о пользователе

            <p class="text-muted mb-4 font-13">Доступные теги: <code class="highlighter-rouge">{bot}, {@bot}, {first_name}, {last_name}, {vk_id}, {date_br}, {city}, {price}, {un_price}, {pay_url}</code></p>

        </label>
        <textarea placeholder="Укажите текст (Обязательно)" class="form-control" name="info_msg" rows="5" style="margin-top: 0px; margin-bottom: 0px; height: 105px;"><? print $reg_msg_two ?></textarea>
    </div>
        <div class="form-group">
            <label for="message">Дополнительное сообщение

                <p class="text-muted mb-4 font-13">Доступные теги: <code class="highlighter-rouge">{first_name}, {last_name}, {rand|min,max}, {gender}</code></p>

            </label>
            <textarea placeholder="Укажите текст (Обязательно)" class="form-control" name="info_msg_2" rows="5" style="margin-top: 0px; margin-bottom: 0px; height: 105px;"><? print $reg_msg_four ?></textarea>
        </div>

        <div class="form-group">
            <label for="message">Подсказка что нужно прислать боту

                <p class="text-muted mb-4 font-13">Доступные теги: <code class="highlighter-rouge">{bot}, {@bot}, {first_name}, {last_name}, {vk_id}</code></p>

            </label>
            <textarea placeholder="Укажите текст (Обязательно)" class="form-control" name="help_msg" rows="5" style="margin-top: 0px; margin-bottom: 0px; height: 105px;"><? print $reg_msg_three ?></textarea>
        </div>

        <style>
            #save, #dont_save{display:none}
        </style>



        </p>





        <div class="form-group">
            <button value="Send" type="submit" class="btn btn-success waves-effect waves-light"><i class="mdi mdi-check-all mr-2"></i>Сохранить</button>
        </div>

        <div id="save" class="alert icon-custom-alert alert-outline-success alert-success-shadow" role="alert">
            <div class="alert-text">
                <i class="mdi mdi-check-all alert-icon"></i>
                <strong>Сохранено!</strong> Настройки успешно сохранены.
            </div>
        </div>

        <div id="dont_save" class="alert icon-custom-alert alert-outline-danger alert-success-shadow" role="alert">
            <div class="alert-text">

                <div id="results"></div>
            </div>
        </div>


    </form>

</div>








<div id="custom-modal" class="modal-demo">
    <button type="button" class="close" onclick="Custombox.modal.close();">
        <span>&times;</span><span class="sr-only">Close</span>
    </button>
    <h4 class="custom-modal-title">Список всех тегов и их описание</h4>
    <div class="custom-modal-text">
        Вcе доступные теги обозначаються рядом с дочерним полем и могут применяться только там, теги прописанные вручную из другой коллекции работать не будут!<br>
        <br>
        Список тегов и их описание:<br>
        {@bot} - Данный тег приобразуется в упоминание сообщетсва от которого пришло сообщение пользователю<br>
        {bot} - Данный тег содержит только названия сообщества, с которого пришло сообщение пользователю<br>

    </div>
</div> <!--end custom modal-->




<div id="custom-modal1" class="modal-demo">
    <button type="button" class="close" onclick="Custombox.modal.close();">
        <span>&times;</span><span class="sr-only">Close</span>
    </button>
    <h4 class="custom-modal-title">Список администраторов</h4>
    <div class="custom-modal-text">
        Укажите через запятую ID пользователей ВК, которые смогут управлять настройками группы через панель управления на сайте. Будьте внимательны, пользователю выдаются полные права на управление группой на сайте VLITO.ru
        <br>
        <br>
        Пользователю не будет доступна панель управления без прав администора в самой группе. Имейте это ввиду!

    </div>
</div> <!--end custom modal-->


<script>


    function call() {
        var msg   = $('#formx').serialize();
        $.ajax({
            type: 'POST',
            url: '/bots/shpion/func.php',
            data: msg,
            success: function(data) {
                console.log(data);
                var obj = jQuery.parseJSON(data);
                if (obj.success == "success") {

                    document.getElementById("save").style.display = "block";
                    document.getElementById("dont_save").style.display = "none";
                }else{
                    $('#results').html(obj.error);
                    document.getElementById("dont_save").style.display = "block";
                    document.getElementById("save").style.display = "none";
                }
            }
        });

    }
    <?

    /*
    function call() {
        var msg   = $('#formx').serialize();
        $.ajax({
            type: 'POST',
            url: '/bots/func.php',
            data: msg,
            success: function(data) {
                document.getElementById("save").style.display = "block";
                document.getElementById("dont_save").style.display = "none";
            },
            error:  function(xhr, str){
                alert('Возникла ошибка: ' + xhr.responseCode);
                document.getElementById("dont_save").style.display = "block";
                document.getElementById("save").style.display = "none";
            }
        });

    }*/

    ?>



</script>