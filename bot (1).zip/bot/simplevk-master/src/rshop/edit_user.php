<?php

if( !defined('ACCESS')) {
    header("HTTP/1.1 403 Forbidden");
    header('Location: ../../');
    die("Hacking attempt!");
}
// === Выгрузка настроек с RSHOP ===

$user_id_rshop = $_GET['id'];

if (!is_numeric($user_id_rshop)){
   include 'rshop/users.php';
}

$settings = $db->query("SELECT * FROM rshop.users WHERE ids = ?i AND group_id = ?i LIMIT 1",$user_id_rshop, $name_group[0]['id'])->fetch_assoc();

if (!$settings) {
    include 'rshop/users.php';
}

$cusers = $vk->userInfo($settings['ids'], ['fields' => 'screen_name, photo_200']);



?>



<div class="tab-pane p-3 active" id="home" role="tabpanel">



    <a href="https://vk.com/id<? print $cusers['id'] ?>" target=\'_blank\'> <img src="<? print$cusers['photo_200'] ?>" alt="" class="rounded-circle thumb-sm mr-1">
        <? print $cusers['first_name'].' '.$cusers['last_name'] ?></a>


    <form method="POST" id="formx" action="javascript:void(null);" onsubmit="call()">



        <input type="hidden" name="type" value="edit_user">
        <input type="hidden" name="group_id" value="<? print $group_id ?>">

        <p class="mb-0 text-muted">


        <div class="form-row">
            <div class="col-md-6 mb-3">
            <label>Никнейм пользователя </label>
            <div class="input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text"><i class="fas fa-user"></i></span>
                </div>
                <input type="text" id="example-input1-group1" name="admin_id" class="form-control" value="<? print $settings['login']; ?>" placeholder="Нужно указать логин пользователя">
            </div>
            </div>

            <div class="col-md-6 mb-3">
                <label>Рейтинг пользователя </label>
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fa fa-star"></i></span>
                    </div>
                    <input type="text" id="example-input1-group1" name="admin_id" class="form-control" value="<? print $settings['rating']; ?>" placeholder="Нужно указать рейтинг пользователя">
                </div>
            </div>

        </div>

        <div class="form-row">
            <div class="col-md-4 mb-3">
                <label>Колличество продаж</label>
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fab fa-amazon-pay"></i></span>
                    </div>
                    <input type="text" name="chat_1" class="form-control" value="<? print $settings['deal']; ?>" placeholder="Продаж...">
                </div>
            </div><!--end col-->
            <div class="col-md-4 mb-3">
                <label>Колличество покупок</label>
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fa fa-shopping-cart"></i></span>
                    </div>
                    <input type="text" name="chat_2" class="form-control" value="<? print $settings['buy']; ?>" placeholder="Покупок...">
                </div>
            </div><!--end col-->
            <div class="col-md-4 mb-3">



                <label>Баланс</label>
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fas fa-money-check-alt"></i></span>
                    </div>
                    <input type="text" name="chat_3" class="form-control" value="<? print $settings['balance']; ?>" placeholder="Баланс">
                </div>
            </div>
        </div>



        <div class="form-group"><hr>
            <label for="example-input1-group1">Платежные данные</label>

        </div>



        <div class="form-row">
            <div class="col-md-3 mb-4">
                <label>Номер карты</label>
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="far fa-credit-card"></i></span>
                    </div>
                    <input type="text" name="percent_virts" class="form-control" value="<? print $settings['card']; ?>" placeholder="Укажите номер карты">
                </div>
            </div><!--end col-->
            <div class="col-md-3 mb-4">
                <label>Номер ЮMoney </label>
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fab fa-yandex-international"></i></span>
                    </div>
                    <input type="text" name="percent_account" class="form-control" value="<? print $settings['yandex']; ?>" placeholder="Укажите номер ЮMoney">
                </div>
            </div><!--end col-->
            <div class="col-md-3 mb-4">



                <label>Номер QIWI</label>
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fas fa-percentage"></i></span>
                    </div>
                    <input type="text" name="percent_asset" class="form-control" value="<? print $settings['qiwi']; ?>" placeholder="Укажите номер QIWI">
                </div>
            </div>
            <div class="col-md-3 mb-4">



                <label>Номер телефона</label>
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fa fa-mobile"></i></span>
                    </div>
                    <input type="text" name="percent_check" class="form-control" value="<? print $settings['mobile']; ?>" placeholder="Укажите номер телефона">
                </div>
            </div>
        </div>

        <hr>
        <div class="form-row">
            <div class="col-md-3 mb-4">
                <label>Статус пользователя</label>



        <select class="custom-select" name="status">
            <?

            switch ($settings['adm']) {

                case 0:
                    print '<option value="0">Пользователь</option>
            <option value="0">Администратор</option>
            <option value="2">Верифицированый</option>
            <option value="3">Временная блокировка</option>
            <option value="4">Заблокированный</option>
            <option value="5">Обнулен</option>';
                    break;
                case 1:
                    print '<option value="1">Администратор</option>
            <option value="0">Пользователь</option>
            <option value="2">Верифицированый</option>
            <option value="3">Временная блокировка</option>
            <option value="4">Заблокированный</option>
            <option value="5">Обнулен</option>';
                    break;
                case 2:
                    print '<option value="2">Верифицированый</option>
            <option value="0">Пользователь</option>
            <option value="1">Администратор</option>
            <option value="3">Временная блокировка</option>
            <option value="4">Заблокированный</option>
            <option value="5">Обнулен</option>';
                    break;
                case 3:
                    print '<option value="3">Временная блокировка</option>
            <option value="1">Пользователь</option>
            <option value="1">Администратор</option>
            <option value="2">Верифицированый</option>
            <option value="4">Заблокированный</option>
            <option value="5">Обнулен</option>';
                    break;
                case 4:
                    print '<option value="4">Заблокированный</option>
            <option value="1">Пользователь</option>
            <option value="1">Администратор</option>
            <option value="2">Верифицированый</option>
            <option value="3">Временная блокировка</option>
            <option value="5">Обнулен</option>';
                    break;
                case 5:
                    print '<option value="5">Обнулен</option>
            <option value="1">Пользователь</option>
            <option value="1">Администратор</option>
            <option value="2">Верифицированый</option>
            <option value="3">Временная блокировка</option>
            <option value="4">Заблокированный</option>
            ';
                    break;
            }


            ?>
        </select>
            </div>


        </div>




        <style>
            #save, #dont_save{display:none}
        </style>



        </p>





        <div class="form-group">
            <button value="Send" type="submit" class="btn btn-success waves-effect waves-light"><i class="mdi mdi-check-all mr-2"></i>Сохранить</button>
        </div>

        <div id="save" class="alert icon-custom-alert alert-outline-success alert-success-shadow" role="alert">
            <div class="alert-text">
                <i class="mdi mdi-check-all alert-icon"></i>
                <strong>Сохранено!</strong> Данные успешно сохранены.
            </div>
        </div>

        <div id="dont_save" class="alert icon-custom-alert alert-outline-danger alert-success-shadow" role="alert">
            <div class="alert-text">

                <div id="results"></div>
            </div>
        </div>


    </form>

</div> <hr>




<?php


$u_balance	= 0.00;
$result	= $db->query("SELECT * FROM enter WHERE group_id = ?i and pay_id = ?i and status = 2", $group_id, $settings['ids']);
while($row = $result->fetch_assoc()) {
    $u_balance = $u_balance + $row['sum'];
}




$u_output	= 0.00;
$result	= $db->query("SELECT * FROM rshop.output WHERE group_id = ?i and ids = ?i", $group_id, $settings['ids']);
while($row = $result->fetch_assoc()) {
    $u_output = $u_output + $row['sum'];
}


?>



<div class="row">


    <div class="col-lg-6">
        <div class="card overflow-hidden">
            <div class="card-body bg-gradient3">
                <div class="">
                    <div class="card-icon">
                        <i class="far fa-smile"></i>
                    </div>
                    <h2 class="font-weight-bold text-white"><? print $u_balance;?> <i class="fas fa-ruble-sign"></i></h2>
                    <p class="text-white mb-0 font-16">Общая сумма пополнений</p>
                </div>
            </div><!--end card-body-->
            <div class="card-body dash-info-carousel">


                <table class="table mb-0">
                    <thead class="thead-light">
                    <tr>
                        <th>#</th>
                        <th>Сумма</th>

                        <th>Дата</th>
                    </tr>
                    </thead>
                    <tbody>




                    <?

                    $result	= $db->query("SELECT * FROM enter WHERE group_id = ?i and status = 2 and pay_id = ?i order by date DESC", $group_id, $settings['ids']);
                    while ($row_user = $result->fetch_assoc()) {


                        $info_vk = unserialize($row_user['info_vk']);
                        $date_time = date('d.m.y H:i:s',$row_user['date']);
                        $date = time_ago(date("Y-m-d H:i:s", $row_user['date']));
                        print "<tr>
        
               <th scope=\"row\">$row_user[id]</th>
                <td>$row_user[sum]</td>

                <td>$date_time ($date)</td>

      </tr>";
                        $i++;
                        $count_balance = $count_balance + $row_user['sum'];
                    }
                    ?>


                    </tbody>
                </table>


            </div><!--end card-body-->
        </div><!--end card-->
    </div><!--end col-->

    <div class="col-lg-6">
        <div class="card overflow-hidden">
            <div class="card-body bg-gradient2">
                <div class="">
                    <div class="card-icon">
                        <i class="fas fa-coins"></i>
                    </div>
                    <h2 class="font-weight-bold text-white"><? print $u_output;?> <i class="fas fa-ruble-sign"></i></h2>
                    <p class="text-white mb-0 font-16">Общая сумма выплат</p>
                </div>
            </div><!--end card-body-->
            <div class="card-body">


                <table class="table mb-0">
                    <thead class="thead-light">
                    <tr>
                        <th>#</th>
                        <th>Сумма</th>

                        <th>Дата</th>
                    </tr>
                    </thead>
                    <tbody>




                    <?

                    $result	= $db->query("SELECT * FROM rshop.output WHERE group_id = ?i and status = 2 and ids = ?i order by date DESC", $group_id, $settings['ids']);
                    while ($row_user = $result->fetch_assoc()) {


                        $info_vk = unserialize($row_user['info_vk']);
                        $date_time = date('d.m.y H:i:s',$row_user['date']);
                        $date = time_ago(date("Y-m-d H:i:s", $row_user['date']));
                        print "<tr>
        
               <th scope=\"row\">$row_user[id]</th>
                <td>$row_user[sum]</td>

                <td>$date_time ($date)</td>

      </tr>";
                        $i++;
                        $count_balance = $count_balance + $row_user['sum'];
                    }
                    ?>


                    </tbody>
                </table>


            </div><!--end card-body-->
        </div><!--end card-->
    </div><!--end col-->
</div>







<div id="custom-modal" class="modal-demo">
    <button type="button" class="close" onclick="Custombox.modal.close();">
        <span>&times;</span><span class="sr-only">Close</span>
    </button>
    <h4 class="custom-modal-title">Список всех тегов и их описание</h4>
    <div class="custom-modal-text">
        Вcе доступные теги обозначаються рядом с дочерним полем и могут применяться только там, теги прописанные вручную из другой коллекции работать не будут!<br>
        <br>
        Список тегов и их описание:<br>
        {@bot} - Данный тег приобразуется в упоминание сообщетсва от которого пришло сообщение пользователю<br>
        {bot} - Данный тег содержит только названия сообщества, с которого пришло сообщение пользователю<br>

    </div>
</div> <!--end custom modal-->

<div id="custom-modal1" class="modal-demo">
    <button type="button" class="close" onclick="Custombox.modal.close();">
        <span>&times;</span><span class="sr-only">Close</span>
    </button>
    <h4 class="custom-modal-title">Список администраторов</h4>
    <div class="custom-modal-text">
        Укажите через запятую ID пользователей ВК, которые смогут управлять настройками группы через панель управления на сайте. Будьте внимательны, пользователю выдаются полные права на управление группой на сайте VLITO.ru
        <br>
        <br>
        Пользователю не будет доступна панель управления без прав администора в самой группе. Имейте это ввиду!

    </div>
</div> <!--end custom modal-->


<script>


    function call() {
        var msg   = $('#formx').serialize();
        $.ajax({
            type: 'POST',
            url: '/bots/rshop/func.php',
            data: msg,
            success: function(data) {
                console.log(data);
                var obj = jQuery.parseJSON(data);
                if (obj.success == "success") {

                    document.getElementById("save").style.display = "block";
                    document.getElementById("dont_save").style.display = "none";
                }else{
                    $('#results').html(obj.error);
                    document.getElementById("dont_save").style.display = "block";
                    document.getElementById("save").style.display = "none";
                }
            }
        });

    }
    <?

    /*
    function call() {
        var msg   = $('#formx').serialize();
        $.ajax({
            type: 'POST',
            url: '/bots/func.php',
            data: msg,
            success: function(data) {
                document.getElementById("save").style.display = "block";
                document.getElementById("dont_save").style.display = "none";
            },
            error:  function(xhr, str){
                alert('Возникла ошибка: ' + xhr.responseCode);
                document.getElementById("dont_save").style.display = "block";
                document.getElementById("save").style.display = "none";
            }
        });

    }*/

    ?>



</script>