<?php

if( !defined('ACCESS') ) {
    header( "HTTP/1.1 403 Forbidden" );
    header ( 'Location: ../../' );
    die( "Hacking attempt!" );
}
// === Выгрузка настроек с VLITO ===

$settings = $db->query("SELECT * FROM rshop.settings WHERE group_id = ?i LIMIT 1", $name_group[0]['id'])->fetch_assoc();


$params = [1 => $select['owner_id'], 2 => $select['owner_id'], 3 => $select['owner_id'], 4 => $select['owner_id'], 5 => $select['owner_id'], 6 => $select['owner_id']];
$params_msg = [
    1 => 'Добро пожаловать в {bot}, {first_name} {last_name}. Что бы начать пользоваться сервисом, нажмите кнопку Регистрация ниже или напишите команду "Регистрация" без кавычек!',
    2 => 'Ваш аккаунт зарегистрирован, Вы можете указать свой псевдоним (Никнейм), отправьте команду "Ник" без кавычек. Наш сервис является приватным сообществом, поэтому просим Вас не указывать ссылки на свои личные страницы и не передавать информацию о себе покупателям или продавцам.',
    3 => 'Добро пожаловать в сервис {bot}. Вы можете использовать кнопки и команды для навигации. Кнопки расположены снизу, открыть команды можно отправив сообщение с текстом "меню" без кавычек',
    4 => 'Список всех текстовых команд для работы с сервисом и быстрого перемещения по нему:
Меню - Перейти на главную
Профиль - Ваш профиль
Купить - Перейти в меню покупки
Продать - Перейти в меню продажи'
];

$params_percent = [1 => 7, 2 => 7, 3 => 7, 4 => 3];


if (!isset($settings))
{

    $db->query("INSERT INTO rshop.settings (reg_msg, peers, group_id) VALUES ('?s', '?s', ?i)", serialize($params_msg), serialize($params), $name_group[0]['id']);
    $settings = $db->query("SELECT * FROM rshop.settings WHERE group_id = ?i LIMIT 1", $name_group[0]['id'])->fetch_assoc();

}


// Беседы
$p =  unserialize($settings['peers']);
if ($p[1] == '') {$p_1 = $params[1]; } else {$p_1 = $p[1];}
if ($p[2] == '') {$p_2 = $params[2]; } else {$p_2 = $p[2];}
if ($p[3] == '') {$p_3 = $params[3]; } else {$p_3 = $p[3];}
if ($p[4] == '') {$p_4 = $params[4]; } else {$p_4 = $p[4];}
if ($p[5] == '') {$p_5 = $params[5]; } else {$p_5 = $p[5];}
if ($p[6] == '') {$p_6 = $params[6]; } else {$p_6 = $p[6];}

// Текст
$reg_msg = unserialize($settings['reg_msg']);
if ($reg_msg[1] == '') {$reg_msg_one = $params_msg[1];} else {$reg_msg_one = $reg_msg[1];}
if ($reg_msg[2] == '') {$reg_msg_two = $params_msg[2];} else {$reg_msg_two = $reg_msg[2];}
if ($reg_msg[3] == '') {$reg_msg_three = $params_msg[3];} else {$reg_msg_three = $reg_msg[3];}
if ($reg_msg[4] == '') {$reg_msg_four = $params_msg[4];} else {$reg_msg_four = $reg_msg[4];}

// Проценты
$all_percent = unserialize($settings['percent']);
if ($all_percent[1] == '') {$all_percent_virts = $params_percent[1];} else {$all_percent_virts = $all_percent[1];}
if ($all_percent[2] == '') {$all_percent_account = $params_percent[2];} else {$all_percent_account = $all_percent[2];}
if ($all_percent[3] == '') {$all_percent_asset = $params_percent[3];} else {$all_percent_asset = $all_percent[3];}
if ($all_percent[4] == '') {$all_percent_check = $params_percent[4];} else {$all_percent_check = $all_percent[4];}




?>



<div class="tab-pane p-3 active" id="home" role="tabpanel">

    <form method="POST" id="formx" action="javascript:void(null);" onsubmit="call()">
    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label for="message">Первое сообщение</label>
                <textarea class="form-control" rows="5" name="start_msg" style="margin-top: 0px; margin-bottom: 0px; height: 97px;"><? print $reg_msg_one ?></textarea>
            </div>
        </div>

        <div class="col-md-6">
            <div class="form-group">
                <label for="message">Сообщение после регистрации</label>
                <textarea class="form-control" rows="5" name="end_reg" style="margin-top: 0px; margin-bottom: 0px; height: 97px;"><? print $reg_msg_two ?></textarea>
            </div>
        </div>
    </div>


        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="message">Приветствие </label>
                    <textarea class="form-control" rows="5" name="hi_msg" style="margin-top: 0px; margin-bottom: 0px; height: 97px;"><? print $reg_msg_three ?></textarea>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <label for="message">Ответ при вызове меню</label>
                    <textarea class="form-control" rows="5" name="msg_four" style="margin-top: 0px; margin-bottom: 0px; height: 97px;"><? print $reg_msg_four ?></textarea>
                </div>
            </div>
        </div>




        <input type="hidden" name="type" value="main_settings">
        <input type="hidden" name="group_id" value="<? print $group_id ?>">

        <p class="mb-0 text-muted">


        <div class="form-group">
            <label for="example-input1-group1">Администраторы через запятую <a href="#custom-modal1" class="btn btn-soft-success btn-round waves-effect waves-light" data-animation="blur" data-plugin="custommodal" data-overlaycolor="#38414a"> ? </a></label>
            <div class="input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text"><i class="fas fa-user"></i></span>
                </div>
                <input type="text" id="example-input1-group1" name="admin_id" class="form-control" value="<? print $select['admin_ids']; ?>" placeholder="183657,87444494">
            </div>
        </div>

        <div class="form-row">
            <div class="col-md-4 mb-3">
                <label>Новые платежи и оповещения</label>
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fab fa-amazon-pay"></i></span>
                    </div>
                    <input type="text" name="chat_1" class="form-control" value="<? print $p_1; ?>" placeholder="2000000001">
                </div>
            </div><!--end col-->
            <div class="col-md-4 mb-3">
                <label>Заявки на вывод</label>
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fas fa-money-bill"></i></span>
                    </div>
                    <input type="text" name="chat_2" class="form-control" value="<? print $p_2; ?>" placeholder="2000000002">
                </div>
            </div><!--end col-->
            <div class="col-md-4 mb-3">



                <label>Беседа споров</label>
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fab fa-napster"></i></span>
                    </div>
                    <input type="text" name="chat_3" class="form-control" value="<? print $p_3; ?>" placeholder="2000000003">
                </div>
            </div>
        </div>



        <div class="form-row">
            <div class="col-md-4 mb-3">
                <label>Активация объявлений</label>
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fas fa-check"></i></span>
                    </div>
                    <input type="text" name="chat_4" class="form-control" value="<? print $p_4; ?>" placeholder="2000000004">
                </div>
            </div><!--end col-->
            <div class="col-md-4 mb-3">
                <label>Платная проверка объявлений</label>
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fas fa-donate"></i></span>
                    </div>
                    <input type="text" name="chat_5" class="form-control" value="<? print $p_5; ?>" placeholder="2000000005">
                </div>
            </div><!--end col-->
            <div class="col-md-4 mb-3">



                <label>Смена ников</label>
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fas fa-user-edit"></i></span>
                    </div>
                    <input type="text" name="chat_6" class="form-control" value="<? print $p_6; ?>" placeholder="2000000006">
                </div>
            </div>
        </div>

        <div class="form-group"><hr>
            <label for="example-input1-group1">Проценты проекта</label>

        </div>



        <div class="form-row">
            <div class="col-md-3 mb-4">
                <label>Процент при продаже ВИРТ</label>
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fas fa-percentage"></i></span>
                    </div>
                    <input type="text" name="percent_virts" class="form-control" value="<? print $all_percent_virts; ?>" placeholder="Укажите процент от 1 до 99">
                </div>
            </div><!--end col-->
            <div class="col-md-3 mb-4">
                <label>Процент при продаже АККАУНТА</label>
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fas fa-percentage"></i></span>
                    </div>
                    <input type="text" name="percent_account" class="form-control" value="<? print $all_percent_account; ?>" placeholder="Укажите процент от 1 до 99">
                </div>
            </div><!--end col-->
            <div class="col-md-3 mb-4">



                <label>Процент при продаже ИМУЩЕСТВА</label>
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fas fa-percentage"></i></span>
                    </div>
                    <input type="text" name="percent_asset" class="form-control" value="<? print $all_percent_asset; ?>" placeholder="Укажите процент от 1 до 99">
                </div>
            </div>
            <div class="col-md-3 mb-4">



                <label>Процент при платной проверке ?</label>
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fas fa-percentage"></i></span>
                    </div>
                    <input type="text" name="percent_check" class="form-control" value="<? print $all_percent_check; ?>" placeholder="Укажите процент от 1 до 99">
                </div>
            </div>
        </div>


        <div class="checkbox checkbox-success">
            <input id="check1" type="checkbox" name="auto_out" value="yes">
            <label for="check1">
                Автоматически отправлять заявки на выплаты
            </label>
        </div>


        <style>
            #save, #dont_save{display:none}
        </style>



        </p>





        <div class="form-group">
            <button value="Send" type="submit" class="btn btn-success waves-effect waves-light"><i class="mdi mdi-check-all mr-2"></i>Сохранить</button>
        </div>

        <div id="save" class="alert icon-custom-alert alert-outline-success alert-success-shadow" role="alert">
            <div class="alert-text">
                <i class="mdi mdi-check-all alert-icon"></i>
                <strong>Сохранено!</strong> Настройки успешно сохранены.
            </div>
        </div>

        <div id="dont_save" class="alert icon-custom-alert alert-outline-danger alert-success-shadow" role="alert">
            <div class="alert-text">

                <div id="results"></div>
            </div>
        </div>


    </form>

</div>








<div id="custom-modal" class="modal-demo">
    <button type="button" class="close" onclick="Custombox.modal.close();">
        <span>&times;</span><span class="sr-only">Close</span>
    </button>
    <h4 class="custom-modal-title">Список всех тегов и их описание</h4>
    <div class="custom-modal-text">
        Вcе доступные теги обозначаються рядом с дочерним полем и могут применяться только там, теги прописанные вручную из другой коллекции работать не будут!<br>
        <br>
        Список тегов и их описание:<br>
        {@bot} - Данный тег приобразуется в упоминание сообщетсва от которого пришло сообщение пользователю<br>
        {bot} - Данный тег содержит только названия сообщества, с которого пришло сообщение пользователю<br>

    </div>
</div> <!--end custom modal-->

                      <div id="custom-modal1" class="modal-demo">
    <button type="button" class="close" onclick="Custombox.modal.close();">
        <span>&times;</span><span class="sr-only">Close</span>
    </button>
    <h4 class="custom-modal-title">Список администраторов</h4>
    <div class="custom-modal-text">
        Укажите через запятую ID пользователей ВК, которые смогут управлять настройками группы через панель управления на сайте. Будьте внимательны, пользователю выдаются полные права на управление группой на сайте VLITO.ru
        <br>
        <br>
        Пользователю не будет доступна панель управления без прав администора в самой группе. Имейте это ввиду!

    </div>
</div> <!--end custom modal-->


<script>


    function call() {
        var msg   = $('#formx').serialize();
        $.ajax({
            type: 'POST',
            url: '/bots/rshop/func.php',
            data: msg,
            success: function(data) {
                console.log(data);
                var obj = jQuery.parseJSON(data);
                if (obj.success == "success") {

                    document.getElementById("save").style.display = "block";
                    document.getElementById("dont_save").style.display = "none";
                }else{
                    $('#results').html(obj.error);
                    document.getElementById("dont_save").style.display = "block";
                    document.getElementById("save").style.display = "none";
                }
            }
        });

    }
    <?

    /*
    function call() {
        var msg   = $('#formx').serialize();
        $.ajax({
            type: 'POST',
            url: '/bots/func.php',
            data: msg,
            success: function(data) {
                document.getElementById("save").style.display = "block";
                document.getElementById("dont_save").style.display = "none";
            },
            error:  function(xhr, str){
                alert('Возникла ошибка: ' + xhr.responseCode);
                document.getElementById("dont_save").style.display = "block";
                document.getElementById("save").style.display = "none";
            }
        });

    }*/

    ?>



</script>