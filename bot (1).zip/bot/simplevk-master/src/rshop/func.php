<?php

define('ACCESS', true);

include '../../cfg.php';
include '../../ini.php';



$sid = $_COOKIE['vlitohash'];
$type = $_POST['type'];
$group_id = $_POST['group_id'];

$user_id = $db->query("SELECT ids FROM users WHERE setcookie = '?s'", $sid)->fetch_assoc()['ids'];


$name_group = $vk->request('groups.getById', ['group_ids' => $group_id, 'fields' => 'admin_level']); //


if ($name_group[0]['is_admin'] == 1 and $name_group[0]['admin_level'] == 3 and $user_id != '' or $adm == 1) {


$select_bots = $db->query("SELECT * FROM bots WHERE bot_id = ?i", $group_id)->fetch_assoc();
$owner_id = $select_bots['owner_id'];
$admins = $select_bots['admin_ids'];
//print_r($_POST);
//Не указано последнее сообщение при завершении регистрации
//    [chat_1] =>
//    [chat_2] =>
//    [chat_3] =>
//    [chat_4] =>
//    [chat_5] =>
//    [chat_6] =>
//






if ($type == "main_settings") {

    $auto_out = $_POST['auto_out'];
    $admin_id = $_POST['admin_id'];
    $chat_1   = $_POST['chat_1'];
    $chat_2   = $_POST['chat_2'];
    $chat_3   = $_POST['chat_3'];
    $chat_4   = $_POST['chat_4'];
    $chat_5   = $_POST['chat_5'];
    $chat_6   = $_POST['chat_6'];
    $start_msg   = $_POST['start_msg'];
    $end_reg   = $_POST['end_reg'];
    $hi_msg   = $_POST['hi_msg'];
    $msg_four = $_POST['msg_four'];
    $all_percent_virts = $_POST['percent_virts'];
    $all_percent_account = $_POST['percent_account'];
    $all_percent_asset  = $_POST['percent_asset'];
    $all_percent_check = $_POST['percent_check'];
    $mess = '';
    if (!$chat_1){ $mess .= 'Не указан ID чата/пользователя 1, поле должно содержать только цифры!<br>'; }
    if (!$chat_2){ $mess .= 'Не указан ID чата/пользователя 2, поле должно содержать только цифры!<br>'; }
    if (!$chat_3){ $mess .= 'Не указан ID чата/пользователя 3, поле должно содержать только цифры!<br>'; }
    if (!$chat_4){ $mess .= 'Не указан ID чата/пользователя 4, поле должно содержать только цифры!<br>'; }
    if (!$chat_5){ $mess .= 'Не указан ID чата/пользователя 5, поле должно содержать только цифры!<br>'; }
    if (!$chat_6){ $mess .= 'Не указан ID чата/пользователя 6, поле должно содержать только цифры!<br>'; }

    if (!$start_msg){ $mess .= 'Не указано стартовое сообщение!<br>'; }
    if (!$end_reg){ $mess .= 'Не указано последнее сообщение при завершении регистрации<br>'; }
    if (!$hi_msg){ $mess .= 'Не указано привествтвие!<br>'; }
    if (!$msg_four){ $mess .= 'Не указано сообщение с командами<br>'; }

    if (!$all_percent_virts || $all_percent_virts < 1 || $all_percent_virts > 99){ $mess .= 'Не верно указан процент поле 1! Значения от 1 до 99, только цифры!<br>'; }
    if (!$all_percent_account || $all_percent_account < 1 || $all_percent_account > 99){ $mess .= 'Не верно указан процент поле 2! Значения от 1 до 99, только цифры!<br>'; }
    if (!$all_percent_asset || $all_percent_asset < 1 || $all_percent_asset > 99){ $mess .= 'Не верно указан процент поле 3! Значения от 1 до 99, только цифры!<br>'; }
    if (!$all_percent_check || $all_percent_check < 1 || $all_percent_check > 99){ $mess .= 'Не верно указан процент поле 4! Значения от 1 до 99, только цифры!<br>'; }

    if ($mess != ''){
        $result = array(
            'success' => "error",
            'error' => "$mess"

        );
        echo json_encode($result);
        exit();
    } else {


        $result = array(
            'success' => "success",
            'error' => "$mess"
        );

        $peers = [1 => $chat_1, 2 => $chat_2, 3 => $chat_3, 4 => $chat_4, 5 => $chat_5, 6 => $chat_6];
        $start_msg = [1 => $start_msg, 2 => $end_reg, 3 => $hi_msg, 4 => $msg_four];
        $all_percent = [1 => $all_percent_virts, 2 => $all_percent_account, 3 => $all_percent_asset, 4 => $all_percent_check];
        $db->query("UPDATE rshop.settings SET peers = '?s', reg_msg = '?s', percent = '?s' WHERE group_id = ?i", serialize($peers), serialize($start_msg), serialize($all_percent), $group_id);
        $db->query("UPDATE bots SET admin_ids = '?s' WHERE bot_id = ?i", $admin_id, $group_id);
    }




}


if($type == "editstatus") {
$check_adm = true;

$id_edit = $_POST['id_edit'];
$error = 0;




$select_owner = $db->query("SELECT * FROM users WHERE ids = ?i", $owner_id)->fetch_assoc();
$balance_owner = $select_owner['balance'];



$select_output = $db->query("SELECT 
rshop.output.group_id as group_id,
rshop.output.ids as ids,
rshop.output.sum as sum,
rshop.output.paysys as paysys,
rshop.output.purse as purse,
rshop.output.info_vk as info_vk 
FROM rshop.output WHERE rshop.output.id = ?i AND rshop.output.status = 0", $id_edit)->fetch_assoc();
$group_id_out = $select_output['group_id'];
$ids_output = $select_output['ids'];
$sum_output = $select_output['sum'];
$paysys_output = $select_output['paysys'];
$purse_output = $select_output['purse'];
$purse_info_vk = $select_output['info_vk'];

$ticket = "RShopPay: Выплата в пользу клиента сервиса $ids_output обработана администратором $ids.";

    if (!$select_output){
        $error = 1;
        $mess = "notoutput";
        $fa = "error";
    }

if ($group_id != $group_id_out){
    $error = 1;
    $mess = "notgroup $group_id - $group_id_out";
    $fa = "error";
}

if ($sum_output > $balance_owner) {

    $error = 1;
    $mess = "notbalance $sum_output - $balance_owner - $group_id - $owner_id";
    $fa = "error";

}

$result = array(
    'success' => "$fa",
    'error' => "$mess"
);


if ($error == 0){



    $id_edit = $_POST['id_edit'];
    $status = $_POST['status'];
    if($check_adm) {
        if($status == "error") {
            $db->query("UPDATE rshop.output SET status = 1 WHERE id = ?i", $id_edit);
            $fa = "success";
        }
        if($status == "succes") {


               $user_infos = $vk->userInfo($owner_id, $scope = ['fields' => 'photo_200']);
              $first_name = $user_infos['first_name'];
               $last_name = $user_infos['last_name'];
              $avatar = $user_infos['photo_200'];


              $array = ['first_name' => $first_name, 'last_name' => $last_name, 'avatar' => $avatar];
            $admin_info = serialize($array);

            $db->query("UPDATE users SET balance = balance - ?i WHERE ids = ?i", $sum_output, $owner_id);
            $db->query("INSERT INTO `output` (`ids`, `sum`, `date`, `login`, `paysys`, `purse`, `status`, ticket, info_vk) VALUES (?i, ?i, ?i, ?i, ?i, '?s', ?i, '?s', '?s')", $owner_id, $sum_output, time(), $owner_id, $paysys_output, $purse_output, 0, $purse_info_vk, $admin_info);
            $db->query("UPDATE rshop.output SET status = 2 WHERE id = ?i", $id_edit);
            $fa = "success";
        }


    }
    $result = array(
        'success' => "$fa",
        'error' => "$sum_output - $balance_owner - $group_id - $owner_id"
    );
}

}

} else {

    $_SESSION['user'] = "";

    setcookie("id_system", '', time() - 1, "/");
    setcookie("vlitohash", '', time() - 1, "/");
    $login = "";
    // print "<html><head><script language=\"javascript\">top.location.href=\"/\";</script></head></html>";
    exit();

}


echo json_encode($result);