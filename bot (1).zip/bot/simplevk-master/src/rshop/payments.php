<?php
print '<div class="tab-pane p-3 active" role="tabpanel">
                                            <p class="mb-0 text-muted">';





                                         print '<div class="col-lg-12">
                            <div class="card">
                                <div class="card-body">
    
                                    <h4 class="mt-0 header-title">Список всех заявок на выплаты</h4>
                                    <p class="text-muted mb-4">Здесь отображаются все заявки созданые для вывода, а так же обработанные ранее
</p>
    
                                    <div class="table-responsive">
                                        <table id="withdraws-tbl" class="table table-bordered mb-0 table-centered">
                                            <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Дата</th>
                                                <th>Сумма</th>
                                           		<th class="tbl-name">ПС</th>
						                        <th class="tbl-name">Кошелек</th>
						                        <th class="tbl-name">VK</th>
                                                <th>Статус</th>
                                            </tr>
                                            </thead>
                                            <tbody>';

$result = $db->query("SELECT * FROM rshop.output WHERE group_id = ?i order by id DESC", $group_id);
$esum = 0;
while ($topics = $result->fetch_assoc()) {

    $esum = sprintf("%01.2f", $esum + $topics['sum']);
    $out_id = $topics['id'];
    $status = $topics['status'];
    $wallet = $topics['purse'];
    $ps = $topics['paysys'];
    $info_vk = unserialize($topics['info_vk']);
    $date = time_ago(date("Y-m-d H:i:s", $topics['date']));

   // $user_infos = $vk->userInfo($topics['ids'], $scope = ['fields' => 'photo_200']);
   // $first_name = $user_infos['first_name'];
  //  $last_name = $user_infos['last_name'];
   // $avatar = $user_infos['photo_200'];




   // $array = ['first_name' => $first_name, 'last_name' => $last_name, 'avatar' => $avatar];
   // $array_next = serialize($array);

    //$db->query("UPDATE rshop.output SET info_vk = '?s' WHERE ids = ?i", $array_next, $topics['ids']);

if($status == 0) {
    $stat = "<td class='sorting_1' tabindex='0' onclick="."$('#editid').html('$out_id');"."  data-toggle='modal' data-target='#editstatus'><span class='badge badge-warning'>Изменить</span></td>";
}
if($status == 2) {
    $stat = "<td class='sorting_1' tabindex='0' style='color:green'><span class='badge badge-success'>Выполнено</span></td>";
}
if($status == 6 or $status == 1) {
    $stat = "<td class='sorting_1' tabindex='0' style='color:red'><span class='badge badge-danger'>Отклонено</span></td>";
}


// 8 юмони 9 киви 13 карта
    if (!$ps){
        $ps = 50;
    }
    print "<tr role='row' id='$out_id' class='odd'>
                                                <td>#$out_id</td>
                                                <td>".date('d.m.y H:i', $topics['date'])." ($date) </td>
                                                <td>$topics[sum]</td>
                                     <td class='sorting_1' tabindex='0'><img src='/img/$ps.svg' width='25' align='25'></td>
<td class='sorting_1' tabindex='0'>$wallet</td>
<td><a href=\"https://vk.com/id$topics[ids]\" target='_blank'> <img src=\"$info_vk[avatar]\" alt=\"\" class=\"rounded-circle thumb-sm mr-1\">
                                                    $info_vk[first_name] $info_vk[last_name]</a></td>
                                                
                                                $stat
                                                

                                            </tr>";

}





                                           print '<tr>
                                                <td></td>
                                                <td>Всего</td>
                                                <td>'.$esum.'</td>
                                     <td></td>
                                     <td></td>
                                      <td></td>          
                                          <td></td>   
                                                

                                            </tr> </tbody>
                                        </table><!--end /table-->
                                    </div><!--end /tableresponsive-->
                                </div><!--end card-body-->
                            </div><!--end card-->
                        </div> <!-- end col -->
                                          
                                       
                                       
                                           <!-- MODAL -->
    <div class="modal fade show infotbl" id="editstatus" tabindex="-1" style="display: none;">
    <div class="modal-dialog modal-dialog-md modal-dialog-centered">
        <div class="modal-content"><a id="close-mod" class="modal-close" data-dismiss="modal" aria-label="Close"><em class="ti ti-close"></em></a>
            <div class="popup-body">
    <center><p>Изменение статуса выплаты <span id=\'editid\' style=\'display:none\'></span></p>
    <hr>
    
    <button class="btn btn-sm btn-outline btn-light input-bordered col-12" style=\'width:140px; display:inline-block\' onclick="withdraw_adm(\'succes\')">Выплачено <i class=\'fa fa-check\' style=\'color:green\'></i></button>  
    
    <button class="btn btn-sm btn-outline btn-light input-bordered col-12" style=\'width:140px; display:inline-block\' onclick="withdraw_adm(\'error\')">Отклонено <i class=\'fa fa-times\' style=\'color:red\'></i></button>
</center>

            </div>
        </div><!-- .modal-content -->
    </div><!-- .modal-dialog -->
</div>
      <!-- END MODAL -->   
                       
                                          
                                          
                                            </p>
                                        </div>   ';

?>

<script>
    function withdraw_adm(status) {
        $.ajax({
            type: 'POST',
            url: '/bots/rshop/func.php',
            beforeSend: function() {

            },

            data: {
                type: "editstatus",
                id_edit: $("#editid").html(),
                status: status,
                group_id: <? print $group_id ?>
            },
            success: function(data) {
                console.log(data);
                var obj = jQuery.parseJSON(data);
                if (obj.success == "success") {
                    $("#close-mod").click();
                    $("#withdraws-tbl").load("/bots/?group=<?print $group_id?>&p=3 #withdraws-tbl");
                }else{
                    $("#close-mod").click();
                    $("#withdraws-tbl").load("/bots/?group=<?print $group_id?>&p=3 #withdraws-tbl");
                }
            }
        });
    }
</script>